// server.js - Simple Node/Express endpoint to forward events to Facebook CAPI
// WARNING: in production store ACCESS_TOKEN securely (env var) and hash user data before sending.
const express = require('express');
const fetch = require('node-fetch'); // v2 style; if using node 18+, can use global fetch
const app = express();
app.use(express.json());

const FB_PIXEL_ID = process.env.FB_PIXEL_ID || 'YOUR_PIXEL_ID';
const ACCESS_TOKEN = process.env.FB_ACCESS_TOKEN || 'YOUR_ACCESS_TOKEN';

app.post('/send-fb-event', async (req, res) => {
  try {
    const event = req.body; // expect event with {event_name, event_time, user_data, custom_data, event_id}
    const payload = {
      data: [
        {
          event_name: event.event_name || 'Purchase',
          event_time: event.event_time || Math.floor(Date.now()/1000),
          event_source_url: event.event_source_url || '',
          event_id: event.event_id || undefined,
          user_data: event.user_data || {},
          custom_data: event.custom_data || {}
        }
      ]
    };

    const url = `https://graph.facebook.com/v17.0/${FB_PIXEL_ID}/events?access_token=${ACCESS_TOKEN}`;
    const r = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    res.json({status:'ok', facebook: data});
  } catch (err) {
    console.error(err);
    res.status(500).json({error: String(err)});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('CAPI proxy listening on', PORT));
