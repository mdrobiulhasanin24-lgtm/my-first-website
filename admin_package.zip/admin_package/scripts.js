// small count-up animation for cards
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.value').forEach(el=>{
    const end = +el.getAttribute('data-count')||0;
    let cur = 0;
    const step = Math.max(1, Math.round(end/40));
    const t = setInterval(()=> {
      cur += step;
      if(cur>=end){ cur=end; clearInterval(t); }
      el.textContent = cur.toLocaleString();
    }, 20);
  });
});
