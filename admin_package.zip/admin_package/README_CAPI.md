Node/Express CAPI Proxy Example
---------------------------------
1. Install:
   npm install

2. Set environment variables:
   export FB_PIXEL_ID=your_pixel_id
   export FB_ACCESS_TOKEN=your_long_lived_token
   (on Windows use set or use a .env approach)

3. Run:
   node server.js

4. Example request:
   POST /send-fb-event
   Body (JSON):
   {
     "event_name": "Purchase",
     "event_time": 1690000000,
     "event_source_url": "https://your-site.com/thankyou",
     "event_id": "order_1234",
     "user_data": {"em":"<sha256_email_hash>"},
     "custom_data": {"currency":"USD","value":249.00}
   }
